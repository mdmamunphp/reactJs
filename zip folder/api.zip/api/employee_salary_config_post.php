<?php
  //require_once("db_config.php");  
  header('Access-Control-Allow-Origin: *'); 
  header("Access-Control-Allow-Headers: X-Requested-With, Content-Type, Origin, Cache-Control, Pragma, Authorization, Accept, Accept-Encoding");
  header('Content-type:application/x-www-form-urlencoded');
  header("Access-Control-Allow-Methods: OPTIONS,GET,POST,PUT,DELETE");
  
  
  $method = $_SERVER['REQUEST_METHOD'];
  

		
  if($method==='POST' && empty($_POST)) {
   $rest_json = file_get_contents("php://input");
    
   $_POST = json_decode($rest_json, true);
  }
  
  $db=new mysqli("localhost","root","","hrm");
  
  $success=0;
  if(isset($_POST)){
	  $employee_id=$_POST["employee_id"];	 
	   $payroll_type_id=$_POST["payroll_type_id"];	 
	    $amount=$_POST["amount"];	 
	 
	  $sql="insert into employee_salary_config set employee_id='$employee_id', payroll_type_id='$payroll_type_id', amount='$amount'";
	$db->query($sql);
	  file_put_contents("data.txt",$employee_id." | ".date("d-m-Y")."\n".$method,FILE_APPEND);  
      	  
	  $success="1";
	  
  }
 
  header('Content-Type: application/json');  
 // echo json_encode(array("success"=>$_POST["name"]));
 //echo json_encode(array("success"=>$data));
 echo json_encode($_POST);
  
?>